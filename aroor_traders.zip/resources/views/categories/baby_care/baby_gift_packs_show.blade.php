<title>Aroor Traders | Baby Gift Packs Categories</title>
@include('header')
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/baby-care-categories">Baby Care /</a>
	  			<a href="/baby-gift-packs-categories">
	  				<b> Baby Gift Packs </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Baby Gift Packs Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Himalaya Gift Pack</h3><a class="imgover" href="#"><img src="https://cdn.shopify.com/s/files/1/0272/4714/9155/products/HIMALAYA_BABY_GIFT_PACK_-_5_in_1_1024x1024.jpg?v=1622100090" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Just Born Baby Toys</h3><a class="imgover" href="#"><img src="https://stylesatlife.com/wp-content/uploads/2016/05/Toys-for-New-Born-Babies-The-Rattle-Set.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">New Born Baby's Gift Set (Unisex)</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/71ZzBeFohVS._SY450_.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Johnson's Baby Care Collection Gift Set</h3><a class="imgover" href="#"><img src="https://www.netmeds.com/images/product-v1/600x600/13743/johnson_s_baby_care_collection_gift_box_compact_0.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
@include('footer')