<title>Aroor Traders | Biscuits Categories</title>
@include('header')
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/snacks">Snacks /</a>
	  			<a href="/biscuits-categories">
	  				<b> Biscuits </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Biscuits Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Britannia Good Day</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/61ZDqyI15GL._SX425_.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Bournvita Crunchy</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/71xTepQPL4L._SX522_.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Unibic - Choco-Kiss</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/xxl/267157_5-unibic-cookies-choco-kiss.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Cadbury Chocobakes</h3><a class="imgover" href="#"><img src="https://osiamart.com/image/cache/catalog/cold-drinks/noodlle/CADBURY%20CHOCOBAKES%20COOKIES150GM-550x550.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Marie Gold</h3><a class="imgover" href="#"><img src="https://i0.wp.com/mart.lexzer.com/wp-content/uploads/2020/04/Britania-Marie-Gold-120-g2.jpg?fit=730%2C469&ssl=1" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Mom's Magic</h3><a class="imgover" href="#"><img src="https://cdn.shopify.com/s/files/1/0173/7644/4470/products/200g_Gallery_1_3a6c7866-f082-4a9d-88da-8b898850e0d8_1024x1024.jpg?v=1623419329" alt=""></a></li>	      	
		    </ul>
	  	</figure>
	</div>
@include('footer')