<title>Aroor Traders | Tomato Categories</title>
@include('header')
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/vegetables-categories">Vegetables /</a>
	  			<a href="/tomato-categories">
	  				<b> Tomato </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Tomato Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Tomato - Naadu</h3><a class="imgover" href="#"><img src="http://uzhavu.in/image/cache/data/uzhavu/Vegetables/new_truss_tomatoes-650x650.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Tomato - Hybrid</h3><a class="imgover" href="#"><img src="https://goodtotake.com/wp-content/uploads/2021/01/Tomato-Hybrid.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
@include('footer')