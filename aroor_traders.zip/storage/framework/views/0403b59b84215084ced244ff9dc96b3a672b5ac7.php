<title>Aroor Traders | Apple Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/fruits">Fruits /</a>
	  			<a href="/apple-categories">
	  				<b> Apple </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Apple Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Red delicious</h3><a class="imgover" href="#"><img src="/images/fruits/apple/apple_red_delicious.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Cortland</h3><a class="imgover" href="#"><img src="/images/fruits/apple/cortland.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Jonagold</h3><a class="imgover" href="#"><img src="/images/fruits/apple/jonagold.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Honeycrisp</h3><a class="imgover" href="#"><img src="/images/fruits/apple/honeycrisp.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/aroor_traders_company/resources/views/categories/fruits/apple/apple_show.blade.php ENDPATH**/ ?>