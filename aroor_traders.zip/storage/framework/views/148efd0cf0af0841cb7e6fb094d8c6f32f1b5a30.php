<title>Aroor Traders | Baby Nail Care Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/baby-care-categories">Baby Care /</a>
	  			<a href="/bath-and-skincare-categories">Baby Nail Care /</a>
	  			<a href="/baby-nail-care">
	  				<b> Baby Nail Care </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Baby Nail Care Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Panache Nail Care Combo</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/l/40160285-2_1-panache-nail-care-combo-colour-may-vary.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Nepee Baby Nail Clipper Kit</h3><a class="imgover" href="#"><img src="https://rukminim1.flixcart.com/image/416/416/kehfi4w0/nail-clipper-cutter/g/q/c/sg-004-sg-004-mukky-original-imafv4wymdwz85sz.jpeg?q=70" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Bulling baby nail trimmer kit for kids</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/71N7T-PveCL._SL1478_.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/www/aroor_traders_company/resources/views/categories/baby_care/baby_nail_care_show.blade.php ENDPATH**/ ?>