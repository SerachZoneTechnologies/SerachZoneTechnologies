<title>Aroor Traders | Fruits</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/fruits">
	  				<b> Fruits </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Fruits</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Apple</h3><a class="imgover" href="/apple"><img src="/images/fruits/apple.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Banana</h3><a class="imgover" href="#"><img src="/images/fruits/banana.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Grapes</h3><a class="imgover" href="#"><img src="/images/fruits/grapes.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Guava</h3><a class="imgover" href="#"><img src="/images/fruits/guava.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Mango</h3><a class="imgover" href="#"><img src="/images/fruits/mango.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Papaya</h3><a class="imgover" href="#"><img src="/images/fruits/papaya.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/aroor_traders_company/resources/views/fruits.blade.php ENDPATH**/ ?>