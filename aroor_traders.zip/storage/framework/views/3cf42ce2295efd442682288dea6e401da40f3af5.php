<title>Aroor Traders | Snacks</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/snacks">
	  				<b> Snacks </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Snacks</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Biscuits</h3><a class="imgover" href="/biscuits-categories"><img src="https://image.shutterstock.com/image-photo/wheat-biscuits-steel-plate-blury-260nw-1824698804.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Crisps</h3><a class="imgover" href="/crisps-categories"><img src="https://keyassets-p2.timeincuk.net/wp/prod/wp-content/uploads/sites/63/2020/01/crisps-920x613.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Namkeen</h3><a class="imgover" href="/namkeen-categories"><img src="https://www.hariomsweets.in/pub/media/catalog/category/chivda-farsan.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/aroor_traders_company/resources/views/categories/snacks/snacks_show.blade.php ENDPATH**/ ?>