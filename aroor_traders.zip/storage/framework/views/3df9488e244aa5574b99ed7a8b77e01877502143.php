<title>Aroor Traders | Baby Bed Set Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/baby-care-categories">Baby Care /</a>
	  			<a href="/baby-bed-set-categories">
	  				<b> Baby Bed Set </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Baby Bed Set Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Quick Dry Baby Bed Protector (Plain Print)</h3><a class="imgover" href="#"><img src="https://assetscdn1.paytm.com/images/catalog/product/F/FA/FASJC-JAIPUR-CRC-R-1131518284AE4C1/1596878337508_0..jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Reversible Nest Bed</h3><a class="imgover" href="#"><img src="https://theshopville.com/wp-content/uploads/2015/03/Baby-Infant-Bed-Canopy-Mosquito-Net-Cotton-padded-Mattress-Pillow-Tent-Foldable-Blue.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Infantbond Combo of Baby Bed with Net</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/81seXWTDFuL._SL1500_.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/www/aroor_traders_company/resources/views/categories/baby_care/baby_bed_set_show.blade.php ENDPATH**/ ?>