<title>Aroor Traders | Onion Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/vegetables">Vegetables /</a>
	  			<a href="/onion-categories">
	  				<b> Onion </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Onion Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Onion - Medium</h3><a class="imgover" href="#"><img src="https://img1.exportersindia.com/product_images/bc-full/dir_140/4184491/onions-medium-1488446494-2736414.jpeg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Sambhar Onion</h3><a class="imgover" href="#"><img src="https://kuttanadandukaan.in/wp-content/uploads/2020/09/0016479_shallotsmall-onion-chota-pyazchinna-vengayam_600.jpeg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/aroor_traders_company/resources/views/categories/vegetables/onion_show.blade.php ENDPATH**/ ?>