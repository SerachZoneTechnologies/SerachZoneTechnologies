<title>Aroor Traders | Papaya Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/fruits">Fruits /</a>
	  			<a href="/papaya-categories">
	  				<b> Papaya </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Papaya Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Ranchi papaya</h3><a class="imgover" href="#"><img src="/images/fruits/papaya/Ranchi-papaya.jpg" alt="Ranchi_papaya"></a></li>
		      	<li class="one_third"><h3 align="center">Organically grown</h3><a class="imgover" href="#"><img src="/images/fruits/papaya/organically-grown.jpg" alt="Organically_grown_papaya"></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/aroor_traders_company/resources/views/categories/fruits/papaya/papaya_show.blade.php ENDPATH**/ ?>