<html>
  	<head>
  		<?php echo $__env->yieldContent('home_page'); ?>
  		<?php echo $__env->yieldContent('fruits'); ?>
		<link href="css/layout.css" rel="stylesheet" type="text/css" media="all">  		
		<script src="/js/jquery.min.js"></script>
		<script src="/js/jquery.backtotop.js"></script>
		<script src="/js/jquery.mobilemenu.js"></script>
	    <!-- Normal Meta Tags-->
	    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	    <meta name="viewport" content="width=device-width, initial-scale = 1.0,maximum-scale=1.0, user-scalable=no"/>
	    <meta name="csrf-token" content=""/>
	    <meta name="google-site-verification" content=""/>
	    <meta property="og:site_name" content="Aroor Traders"/>
	    <meta name="copyright" content="Aroor Traders"/>
	    <meta name="robots" content="All"/>
	    <meta name="coverage" content="Worldwide"/>
	    <meta content="IE=edge" http-equiv="X-UA-Compatible"/>
	    <meta name="rating" content="general"/>
	    <meta name="distribution" content="global"/> 
	    <meta name="language" content="EN"/>
	    <meta name="geo.position" content="0000,0000"/><!-- Check out the location -->
	    <meta http-equiv="Cache-control" content="public,max-age:2628000">
	    <link rel="publisher" href=""/>
	    <meta name="google-site-verification" content=""/>
	   
	    <meta property="og:site_name" content="Aroor Traders"/>
	    <meta name="geo.position" content="0000,0000"/>
	    <link rel="dns-prefetch" href="//www.googletagmanager.com">

	    <!-- DNS Prefetch -->
	    <!-- <link rel="dns-prefetch" href="//embed.tawk.to"> -->
	    <!-- Chat Application  -->
	  	<!-- <script type="text/javascript" defer>var Tawk_API=Tawk_API||{},Tawk_LoadStart=new Date();(function(){var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];s1.async=true;s1.src='https://embed.tawk.to/5c822d36c37db86fcfccaae3/default';s1.charset='UTF-8';s1.setAttribute('crossorigin','*');s0.parentNode.insertBefore(s1,s0);})();</script> -->
  	</head>
</html><?php /**PATH /home/dhivya/aroor_traders_company/resources/views/head.blade.php ENDPATH**/ ?>