<title>Aroor Traders | Atta Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/food-grain-categories">Food Grains Categories /</a>
	  			<a href="/atta-categories">
	  				<b> Atta </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Atta Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Aashirvaad Multigrains Atta</h3><a class="imgover" href="#"><img src="https://5.imimg.com/data5/BV/HI/GLADMIN-23977148/aashirvaad-multigrain-atta-500x500.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Pillsbury Atta - Multigrain</h3><a class="imgover" href="#"><img src="https://ravis-supermart.com/wp-content/uploads/2019/03/Flour_PILLSBURYWheatFlour.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">BB Royal Multigrain Atta - Fortified</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/xxl/40189432-2_2-bb-royal-multigrain-atta-fortified.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/www/aroor_traders_company/resources/views/categories/food_grains/atta/atta_show.blade.php ENDPATH**/ ?>