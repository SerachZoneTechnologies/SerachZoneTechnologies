<title>Aroor Traders | Baby Foods Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/baby-care-categories">Baby Care /</a>
	  			<a href="/baby-foods-categories">
	  				<b> Baby Foods </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Baby Foods Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Nestle Baby Food - Ceregrow</h3><a class="imgover" href="#"><img src="https://shopma.com.np/MediaThumb/medium/Media/Nestle/nestle-ceregrow-multigrain-cereal-w.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Nestle Cerelac Baby Cereal with Milk - Wheat-Rice Mixed Fruit</h3><a class="imgover" href="#"><img src="https://newassets.apollo247.com/pub/media/catalog/product/c/e/cer0055.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Slurrp Farm Organic Baby Cereal</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/71lQADx7QCL._SL1500_.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/www/aroor_traders_company/resources/views/categories/baby_care/baby_foods_show.blade.php ENDPATH**/ ?>