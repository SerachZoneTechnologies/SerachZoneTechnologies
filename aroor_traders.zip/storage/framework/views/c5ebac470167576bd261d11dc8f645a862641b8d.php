<title>Aroor Traders | Dal Varieties</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/dal-varieties">
	  				<b> Dal Varieties </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Dal Varieties</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Moong Dal</h3><a class="imgover" href="/dal-varieties"><img src="/images/dal_varieties/Moong_Dal.jpg" alt="Moong_Dal"></a></li>
		      	<li class="one_third"><h3 align="center">Chana Dal</h3><a class="imgover" href="/dal-varieties"><img src="/images/dal_varieties/Chana_Dal.jpg" alt="Chana_Dal"></a></li>
		      	<li class="one_third"><h3 align="center">Urad Dal</h3><a class="imgover" href="/dal-varieties"><img src="/images/dal_varieties/Urad_Dal.jpg" alt="Urad_Dal"></a></li>
		      	<li class="one_third"><h3 align="center">Masoor Dal</h3><a class="imgover" href="/dal-varieties"><img src="/images/dal_varieties/Masoor_Dal.jpg" alt="Masoor_Dal"></a></li>
		      	<li class="one_third"><h3 align="center">Green Moong Dal</h3><a class="imgover" href="/dal-varieties"><img src="/images/dal_varieties/Green_Moong_Dal.jpg" alt="Green_Moong_Dal"></a></li>
		      	<li class="one_third"><h3 align="center">Pigeon pea</h3><a class="imgover" href="/dal-varieties"><img src="/images/dal_varieties/Pigeon _pea.jpg" alt="Pigeon_pea"></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/www/aroor_traders_company/resources/views/categories/dal_varieties/dal_varieties_show.blade.php ENDPATH**/ ?>