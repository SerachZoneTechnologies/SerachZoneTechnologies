<title>Aroor Traders | Broken Raw Rice Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/food-grain-categories">Food Grains Categories /</a>
	  			<a href="/rice-categories">Rice /</a>
	  			<a href="/broken-rice-categories">
	  				<b> Broken Raw Rice </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Broken Raw Rice Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Broken Raw Rice 30</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/81ERhO%2BhemL._SL1500_.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Broken Raw Rice 34</h3><a class="imgover" href="#"><img src="https://m.media-amazon.com/images/I/61RpH1ZqW+L._SL1280_.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Broken Raw Rice 40</h3><a class="imgover" href="#"><img src="https://cdn.shopify.com/s/files/1/0475/8398/5816/products/Broken_rice_700x700.jpg?v=1605758273" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/www/aroor_traders_company/resources/views/categories/food_grains/rice/broken_rice_show.blade.php ENDPATH**/ ?>