<title>Aroor Traders | Lamp oil Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/oil-categories">Oils /</a>
	  			<a href="/lamp-oil-categories">
	  				<b> Lamp oil </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Lamp oil Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Dheepam lamp oil</h3><a class="imgover" href="#"><img src="https://metromartonline.com/wp-content/uploads/2020/08/dheepam-lamp-oil-scaled.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Dheepam temple lamp oil</h3><a class="imgover" href="#"><img src="https://svshomeneeds.com/wp-content/uploads/2020/02/20200221_185904-scaled.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/aroor_traders_company/resources/views/categories/oils/lamp_oil_show.blade.php ENDPATH**/ ?>