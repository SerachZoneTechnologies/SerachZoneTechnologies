<title>Aroor Traders | Bakery</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/bakery">
	  				<b> Bakery </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Bakery</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Amul - Butter Pasteurized</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/61vr7r8qqsL._SL1057_.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Amul - Homogenised Toned Milk</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/xxl/306926_2-amul-homogenised-toned-milk.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Amul - Cheese Slices</h3><a class="imgover" href="#"><img src="https://5.imimg.com/data5/XI/YS/MY-4644168/amul-cheese-slices-5-pc-500x500.png" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Amul Malai Fresh Paneer</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/xxl/40096747_7-amul-malai-fresh-paneer.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Brown Bread</h3><a class="imgover" href="#"><img src="https://4.imimg.com/data4/HR/KI/MY-6834185/brown-bread-500x500.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Whole Wheat Bread</h3><a class="imgover" href="#"><img src="https://sugargeekshow.com/wp-content/uploads/2020/03/whole-wheat-bread-recipe-featured.jpg" alt=""></a></li>		      	
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/aroor_traders_company/resources/views/categories/bakery/bakery_show.blade.php ENDPATH**/ ?>