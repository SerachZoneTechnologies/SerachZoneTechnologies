<title>Aroor Traders | Idly Rice Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/food-grain-categories">Food Grains Categories /</a>
	  			<a href="/rice-categories">Rice /</a>
	  			<a href="/idly-rice-categories">
	  				<b> Idly Rice </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Idly Rice Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Idly Rice 42</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/41WJQCJS4oS.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Idly Rice 40</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/41f5-DC-3TL.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/www/aroor_traders_company/resources/views/categories/food_grains/rice/idly_rice_show.blade.php ENDPATH**/ ?>