<title>Aroor Traders | Namkeen Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/snacks">Snacks /</a>
	  			<a href="/namkeen-categories">
	  				<b> Namkeen </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Namkeen Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Namkeen - Moong Dal</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/l/100022551_1-haldirams-namkeen-moong-dal.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Namkeen - Aloo Bhujia</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/l/264454_1-haldirams-namkeen-aloo-bhujia.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Namkeen - Bhujia Sev</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/l/264456_7-haldirams-namkeen-bhujia-sev.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Namkeen - Lite Chiwda</h3><a class="imgover" href="#"><img src="https://images.jdmagicbox.com/quickquotes/images_main/haldiram-s-namkeen-lite-chiwda-30-gm-160110011-q4wp3.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Namkeen - Khatta Meetha</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/714U%2BIiO7lL._SL1500_.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Namkeen - Tasty Nuts</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/xxl/20002446_8-haldirams-namkeen-tasty-nuts.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Namkeen - Ribbon Pakoda</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/l/40123672_5-townbus-namkeen-ribbon-pakoda.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Namkeen - Butter Murukku</h3><a class="imgover" href="#"><img src="https://www.bigbasket.com/media/uploads/p/xxl/40123673_4-townbus-namkeen-butter-murukku.jpg" alt=""></a></li>
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/aroor_traders_company/resources/views/categories/snacks/namkeen_show.blade.php ENDPATH**/ ?>