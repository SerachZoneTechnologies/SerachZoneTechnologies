<title>Aroor Traders | Crisps Categories</title>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="bgded overlay" style="background-image:url('images/demo/backgrounds/01.png');">
	  	<figure class="hoc container clear imgroup">
	  		<h6>
	  			<a href="/">Main Categories /</a>
	  			<a href="/snacks">Snacks /</a>
	  			<a href="/crisps-categories">
	  				<b> Crisps </b>
	  			</a>
	  		</h6>
		    <figcaption class="sectiontitle">
		      	<p class="heading underline font-x2">Crisps Categories</p>
		    </figcaption>
		    <ul class="nospace group">
		      	<li class="one_third"><h3 align="center">Potato chips - Salt</h3><a class="imgover" href="#"><img src="https://www.chocolatemoosey.com/wp-content/uploads/2013/09/Homemade-Salt-And-Vinegar-Chips-7809-2.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Potato chips - Pepper</h3><a class="imgover" href="#"><img src="https://5.imimg.com/data5/QV/XW/JV/SELLER-47561870/kali-mirch-chips-500x500.jpeg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Potato Chips - Classic Salted</h3><a class="imgover" href="#"><img src="https://s3.ap-south-1.amazonaws.com/diingdong/KBZ0002444.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Potato Chips - American Style Cream & Onion Flavour</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/51TVt9Qe8pL.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Potato Chips - Indias Magic Masala</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/71FFI9ErOWL._SX522_.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Potato Chips - Spanish Tomato Tango</h3><a class="imgover" href="#"><img src="https://5.imimg.com/data5/UK/LQ/WR/SELLER-82456434/potato-chips-500x500.jpg" alt=""></a></li>
		      	<li class="one_third"><h3 align="center">Potato Chips - Calm Cream & Onion Flavour</h3><a class="imgover" href="#"><img src="https://images-na.ssl-images-amazon.com/images/I/51aCTde%2Bp6L.jpg" alt=""></a></li>		      	     	
		    </ul>
	  	</figure>
	</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dhivya/aroor_traders_company/resources/views/categories/snacks/crisps_show.blade.php ENDPATH**/ ?>